/**
 * Created by hxsd on 2016/8/3.
 */
angular.module("myapp2",["ionic"]);
angular.module("myapp2").controller("myctrlsc",function($scope,$http,$ionicScrollDelegate){
    $scope.scimg = [
        {imgsrc:"../images/scimg_03.png",title:"电影级游戏CG与震撼心灵的史诗音乐推荐合集第二弹",fons:"分类:GMV"},
        {imgsrc:"../images/scimg_06.png",title:"【MineCraft】B站建筑比赛 建筑展示",fons:"分类:单机联机"},
        {imgsrc:"../images/scimg_08.png",title:"磁铁和大理石打造趣味卢布。戈德堡机械",fons:"分类:趣味科普人文"},
        {imgsrc:"../images/scimg_10.png",title:"【星际2】电竞毒奶黄旭东 我以前迷信科学直到。。。",fons:"分类:网游.电竞"},
        {imgsrc:"../images/scimg_12.png",title:"【台湾解说1小时版】2016MSI季中赛RNG VS  SKT1 高清",fons:"分类:网游.电竞"},
        {imgsrc:"../images/scimg_14.png",title:"【新鬼泣】黑瞳谷歌视频攻略SOS难度",fons:"分类:单机联机"}
    ]
    $scope.scimg2 = [
        {imgsrc:"../images/scimg_14.png",title:"【新鬼泣】黑瞳谷歌视频攻略SOS难度",fons:"分类:单机联机"},
        {imgsrc:"../images/scimg_12.png",title:"【台湾解说1小时版】2016MSI季中赛RNG VS  SKT1 高清",fons:"分类:GMV"},
        {imgsrc:"../images/scimg_10.png",title:"磁铁和大理石打造趣味卢布。戈德堡机械",fons:"分类:趣味科普人文"},
        {imgsrc:"../images/scimg_08.png",title:"【星际2】电竞毒奶黄旭东 我以前迷信科学直到。。。",fons:"分类:网游.电竞"},
        {imgsrc:"../images/scimg_06.png",title:"【MineCraft】B站建筑比赛 建筑展示",fons:"分类:单机联机"},
        {imgsrc:"../images/scimg_03.png",title:"电影级游戏CG与震撼心灵的史诗音乐推荐合集第二弹",fons:"分类:GMV"}
    ]
    $scope.scimg3 = [
        {imgsrc:"../images/scimg_06.png",title:"【MineCraft】B站建筑比赛 建筑展示",fons:"分类:单机联机"},
        {imgsrc:"../images/scimg_10.png",title:"电影级游戏CG与震撼心灵的史诗音乐推荐合集第二弹",fons:"分类:GMV"},
        {imgsrc:"../images/scimg_14.png",title:"【星际2】电竞毒奶黄旭东 我以前迷信科学直到。。。",fons:"分类:GMV"},
        {imgsrc:"../images/scimg_12.png",title:"磁铁和大理石打造趣味卢布。戈德堡机械",fons:"分类:趣味科普人文"},
        {imgsrc:"../images/scimg_08.png",title:"【新鬼泣】黑瞳谷歌视频攻略SOS难度",fons:"分类:GMV"},
        {imgsrc:"../images/scimg_03.png",title:"【台湾解说1小时版】2016MSI季中赛RNG VS  SKT1 高清",fons:"分类:网游.电竞"}
    ];
    var index = 0;
    $interval(function(){
        index = (index+1)%3;
        $ionicTabsDelegate.select(index);
    },3000);

    //$scope.products = [
    //    {title: "商品A", dscr: "好商品", mgsrc: "images/574d5462N5b2cf38b.jpg"},
    //    {title: "商品B", dscr: "好商品", mgsrc: "images/574d5462N5b2cf38b.jpg"},
    //    {title: "商品C", dscr: "好商品", mgsrc: "images/574d5462N5b2cf38b.jpg"},
    //    {title: "商品D", dscr: "好商品", mgsrc: "images/574d5462N5b2cf38b.jpg"},
    //    {title: "商品E", dscr: "好商品", mgsrc: "images/574d5462N5b2cf38b.jpg"}
    //]
    $scope.data = {
        showDelete: false,
        showreorder: false
    }
    $scope.delete = function (product) {
        var index = $scope.products.indexOf(product);

        $scope.products.splice(index, 1);
    }
    $scope.order = function (product, form, to) {
        $scope.products.splice(form, 1);

        $scope.products.splice(to, 0, product);
    }
    $scope.edit = function (product) {
        alert(product.title);
    }
    $scope.share = function (product) {
        alert(product.title);
    }
    $scope.refresh = function () {
        $http.get("../data.json").success(function (data) {
            console.log(data);
            $scope.products = data;
        }).finally(function () {
            $scope.$broadcast("scroll.refreshComplete");
        })
    };
    $scope.loadMore = function () {
        $http.get("../data.json").success(function (data) {
            Array.prototype.push.apply($scope.products, data)
        }).finally(function () {
            $scope.$broadcast("scroll.infiniteScrollComplete")
        })
    };
    $scope.toTop = function () {
        $ionicScrollDelegate.scrollTop(true)
    }
    $scope.slideChange = function (index) {
        console.log("index:" + index)
    }
    $scope.pageclick = function (index) {
        $scope.page = index;
    }
})
