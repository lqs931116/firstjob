
var myapp = angular.module("myapp",["ionic","ngRoute","ngAnimate"]);
myapp.controller("myctrl",function($scope,$http,$ionicScrollDelegate,$ionicModal){

    // 构造模对话框
    $ionicModal.fromTemplateUrl('views/modal.html', {
        scope: $scope,       // 作用域使用父作用域
        animation: 'slide-in-up'
//                        animation: 'slide-in-left'
//                        animation: 'slide-in-right'
//                        animation: 'scale-in'
    }).then(function(modal) {
        $scope.modal = modal;
    });
    $ionicModal.fromTemplateUrl('views/modal2.html', {
        scope: $scope,       // 作用域使用父作用域
        animation: 'slide-in-up'
//                        animation: 'slide-in-left'
//                        animation: 'slide-in-right'
//                        animation: 'scale-in'
    }).then(function(modal) {
        $scope.modal2 = modal;
    });

    $scope.openModal = function() {
        $scope.modal.show();
    };

    $scope.closeModal = function() {
        $scope.modal.hide();
    };
    $scope.openModal2 = function() {
        $scope.modal2.show();
    };

    $scope.closeModal2 = function() {
        $scope.modal2.hide();
    };
    $scope.rec = false;
    $scope.reca = function(){
        $scope.rec = !$scope.rec;
    }
    $scope.dis = function(){
        $scope.rec =false;
    }
    // ionScroll的高度，是窗口的总高度-标题栏的高度
    $scope.scrh = function(){
        return parseInt(window.innerHeight)  + "px";
    };
    $scope.colr = "#eaeaea";
    $scope.col = function(color){
      return  $scope.colr = color;
    }
    $scope.slideChange=function(index){
        console.log("index:"+index);
    }
    $scope.page=function(index){
        console.log("i"+index);
    }
    $scope.performs1 = [
        {imgsrc:"../images/perfore_05.png",title:"H萌动漫秀",pconts:"5.4万",fons:"2611"},
        {imgsrc:"../images/perfore_07.png",title:"暴戾龙DAZE",pconts:"4.7万",fons:"957"},
    ];
    $scope.performs2 = [
        {imgsrc:"../images/perfore_11.png",title:"全明星【宅】",pconts:"9.8万",fons:"6520"},
        {imgsrc:"../images/perfore_12.png",title:"反派团热跳杀马特",pconts:"7.5万",fons:"3632"}
    ]
    $scope.zb1 = [
        {imgsrc:"../images/zb-1_05.png",title:"H萌动漫秀",pconts:"黑桐谷歌",fons:"2611"},
        {imgsrc:"../images/zb-1_07.png",title:"暴戾龙DAZE",pconts:"纯黑大叔",fons:"957"},
    ];
    $scope.zb2 = [
        {imgsrc:"../images/zb-1_11.png",title:"全明星【宅】",pconts:"灵哀寒",fons:"6520"},
        {imgsrc:"../images/zb-1_12.png",title:"反派团热跳杀马特",pconts:"小圆喵",fons:"3632"}
    ]
    $scope.zb3 = [
        {imgsrc:"../images/zb-2_03.png",title:"H萌动漫秀",pconts:"哔哩哔哩音乐台",fons:"2611"},

    ];
    $scope.zb4 = [
        {imgsrc:"../images/zb-2_08.png",title:"H萌动漫秀",pconts:"平胸菜菜子",fons:"2611"},
        {imgsrc:"../images/zb-2_06.png",title:"暴戾龙DAZE",pconts:"红丹 ",fons:"957"},
    ];

    $scope.zb5 = [
        {imgsrc:"../images/zb-2_11.png",title:"H萌动漫秀",pconts:"DOTA",fons:"2611"},
        {imgsrc:"../images/zb-2_12.png",title:"暴戾龙DAZE",pconts:"镇长",fons:"957"},
    ];

    $scope.pef1 = [
        {imgsrc:"../images/pef2_03.png",title:"当英雄不如跳舞",pconts:"2792",fons:"62"},
        {imgsrc:"../images/pef2_05.png",title:"不完美小孩",pconts:"3784",fons:"183"},
    ];
    $scope.pef2 = [
        {imgsrc:"../images/pef2_09.png",title:"自杀小队",pconts:"1.8万",fons:"327"},
        {imgsrc:"../images/pef2_10.png",title:"至黑之夜",pconts:"3566",fons:"103"}
    ];
    $scope.showstate = false;
    $scope.shown = function(){
        $scope.showstate = !$scope.showstate;
    }
    $scope.dis = function(){
        $scope.showstate = false;
    }
    $scope.gz1 = [
        {imgsrc:"../images/guanzhu_03.png",name:"RE:从零开始的异世界生活",tag1:"看到第18话",tag2:"更新至18话更新至18话"},
        {imgsrc:"../images/guanzhu_05.png",name:"偶像大师 灰姑娘女孩",tag1:"看到第3话",tag2:"更新至第13话"},
        {imgsrc:"../images/guanzhu_07.png",name:"发条精灵战记",tag1:"看到第3话",tag2:"更新至第4话"},
    ]

    $scope.fj1 = [
        {imgsrc:"../images/fj.lz_05.png",name:"灵能百分百",tag1:"更新至第4话"},
        {imgsrc:"../images/fj.lz_07.png",name:"加速世界 infinite burst",tag1:"更新至第1话"},
        {imgsrc:"../images/fj.lz_09.png",name:"RE:从零开始的异世界生活",tag1:"更新至第18话"},
    ];
    $scope.fj2 = [
        {imgsrc:"../images/fj.lz_07.png",name:"加速世界 infinite burst",tag1:"更新至第1话"},
        {imgsrc:"../images/fj.lz_05.png",name:"灵能百分百",tag1:"更新至第4话"},
        {imgsrc:"../images/fj.lz_09.png",name:"RE:从零开始的异世界生活",tag1:"更新至第18话"},
    ]
    $scope.fj3 = [
        {imgsrc:"../images/fjtj_03.png",name:"从零开始的异世界生活 18",tag1:"绝望了吗 放弃了了？"},
        {imgsrc:"../images/fjtj_06.png",name:"REWIRITE",tag1:"小鸟太可爱了！"},
        {imgsrc:"../images/fjtj_06_06.png",name:"色彩的绚丽月之音",tag1:"12色的绚丽月之音"},
        {imgsrc:"../images/fjtj_03.png",name:"从零开始的异世界生活 18",tag1:"绝望了吗 放弃了了？"},
    ]
    $scope.refresh = function () {
        $http.get("data4.json").success(function (data) {
            console.log(data);
            $scope.fj3 = data;
        }).finally(function () {
            $scope.$broadcast("scroll.refreshComplete");
        })
    };
    $scope.loadMore = function () {
        $http.get("data3.json").success(function (data) {
            Array.prototype.push.apply($scope.fj3, data)
        }).finally(function () {
            $scope.$broadcast("scroll.infiniteScrollComplete")
        })
    };
})
myapp.controller("myctrl2",function($scope){
})
myapp.config(function($routeProvider){
    $routeProvider.when("/bibili-tuijian",{templateUrl:"../views/bibili-tuijian.html"});
    $routeProvider.when("/faxian",{templateUrl:"../views/faxian.html",controller:"myctrl2"});
    $routeProvider.when("/fenqu",{templateUrl:"../views/fenqu.html"});
    $routeProvider.when("/guanzhu",{templateUrl:"../views/guanzhu.html"});
    $routeProvider.when("/zb",{templateUrl:"../views/zb.html"});
    $routeProvider.when("/fanju",{templateUrl:"../views/fanju.html"});
    $routeProvider.otherwise({templateUrl:"../views/bibili-tuijian.html"});
});
myapp.controller("myctrlsc",function($scope,$ionicTabsDelegate,$interval){
    $scope.scimg = [
        {imgsrc:"../images/scimg_03.png",title:"电影级游戏CG与震撼心灵的史诗音乐推荐合集第二弹",fons:"分类:GMV"},
        {imgsrc:"../images/scimg_06.png",title:"【MineCraft】B站建筑比赛 建筑展示",fons:"分类:单机联机"},
        {imgsrc:"../images/scimg_08.png",title:"磁铁和大理石打造趣味卢布。戈德堡机械",fons:"分类:趣味科普人文"},
        {imgsrc:"../images/scimg_10.png",title:"【星际2】电竞毒奶黄旭东 我以前迷信科学直到。。。",fons:"分类:网游.电竞"},
        {imgsrc:"../images/scimg_12.png",title:"【台湾解说1小时版】2016MSI季中赛RNG VS  SKT1 高清",fons:"分类:网游.电竞"},
        {imgsrc:"../images/scimg_14.png",title:"【新鬼泣】黑瞳谷歌视频攻略SOS难度",fons:"分类:单机联机"}
    ]
    $scope.scimg2 = [
        {imgsrc:"../images/scimg_14.png",title:"【新鬼泣】黑瞳谷歌视频攻略SOS难度",fons:"分类:单机联机"},
        {imgsrc:"../images/scimg_12.png",title:"【台湾解说1小时版】2016MSI季中赛RNG VS  SKT1 高清",fons:"分类:GMV"},
        {imgsrc:"../images/scimg_10.png",title:"磁铁和大理石打造趣味卢布。戈德堡机械",fons:"分类:趣味科普人文"},
        {imgsrc:"../images/scimg_08.png",title:"【星际2】电竞毒奶黄旭东 我以前迷信科学直到。。。",fons:"分类:网游.电竞"},
        {imgsrc:"../images/scimg_06.png",title:"【MineCraft】B站建筑比赛 建筑展示",fons:"分类:单机联机"},
        {imgsrc:"../images/scimg_03.png",title:"电影级游戏CG与震撼心灵的史诗音乐推荐合集第二弹",fons:"分类:GMV"}
    ]
    $scope.scimg3 = [
        {imgsrc:"../images/scimg_06.png",title:"【MineCraft】B站建筑比赛 建筑展示",fons:"分类:单机联机"},
        {imgsrc:"../images/scimg_10.png",title:"电影级游戏CG与震撼心灵的史诗音乐推荐合集第二弹",fons:"分类:GMV"},
        {imgsrc:"../images/scimg_14.png",title:"【星际2】电竞毒奶黄旭东 我以前迷信科学直到。。。",fons:"分类:GMV"},
        {imgsrc:"../images/scimg_12.png",title:"磁铁和大理石打造趣味卢布。戈德堡机械",fons:"分类:趣味科普人文"},
        {imgsrc:"../images/scimg_08.png",title:"【新鬼泣】黑瞳谷歌视频攻略SOS难度",fons:"分类:GMV"},
        {imgsrc:"../images/scimg_03.png",title:"【台湾解说1小时版】2016MSI季中赛RNG VS  SKT1 高清",fons:"分类:网游.电竞"}
    ];
})
