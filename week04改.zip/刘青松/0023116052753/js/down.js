/**
 * Created by hxsd on 2016/8/4.
 */
var psapp = angular.module("psapp",[]);
psapp.controller("myc",function($scope){
    $scope.st = false;
    $scope.ch = function(){
        $scope.st = true
    }
    $scope.ch2 = function(){
        $scope.st = false;
    }
})