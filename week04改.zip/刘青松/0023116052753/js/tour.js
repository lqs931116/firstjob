/**
 * Created by hxsd on 2016/8/4.
 */
angular.module("myapp",["ionic"]);
angular.module("myapp").controller("myCtrl",function($scope,$http,$ionicScrollDelegate){
//            $scope.slideChange=function(index){
//                console.log("index:"+index);
//            }
//            $scope.page=function(index){
//                console.log("i"+index);
//            }
})